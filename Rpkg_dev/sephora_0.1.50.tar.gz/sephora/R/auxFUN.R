

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# --- FUNCTIONS used to smooth raw time series, apply hierarchical clustering
# --- fit mixed model, find critical points of fpca fit
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

tsclusters_centroid <- function(m, type='h', seed, distance="L2",
                                trace){
  
  clust <- tsclust(series=m, type = type, seed = seed, distance = distance, 
                   centroid = dtwclust::shape_extraction, trace = trace, 
                   control = dtwclust::hierarchical_control(method = "average"))
  clust
}

# --- added on Sept 30, 2022 during check of sephora package
dbind <- function (M1, M2) {
  if (is.null(M1)) {
    p <- M2
  }
  else {
    if (is.null(M2)) {
      p <- M1
    }
    else {
      r1 <- dim(M1)[1]
      r2 <- dim(M2)[1]
      c1 <- dim(M1)[2]
      c2 <- dim(M2)[2]
      r <- r1 + r2
      c <- c1 + c2
      p <- matrix(rep(0, r * c), ncol = c)
      p[(1:r1), (1:c1)] <- M1
      p[((r1 + 1):r), ((c1 + 1):c)] <- M2
    }
  }
  
  return(p)
}

spectralnorm <- function (M) {
  result <- sqrt(max(svd(t(M) %*% M)$d))
  return(result)
}

show_condition <- function(code) {
  tryCatch(code, error = function(c) "ERROR")
}

# ==============================================================================
# --- Auxiliary functions for new_getSmoothing()
# ==============================================================================

AIC <- function(nparams, likelihood){
  2*nparams - 2 * likelihood
}

BIC <- function(nparams, likelihood, n){
  nparams * log(n) - 2 * likelihood
}

log_like_OLS <- function(sigma, y, fit){
  -length(fit) * log(sigma)  -(1/(2*sigma^2)) * sum( (y-fit)^2 ) 
}

log_like_WLS <- function(sigma, y, fit){
  
  sum( -1 * log(sigma) ) - (1/2) * sum( (y-fit)^2/sigma^2 )
}

.fitHarmonicModel <- function(y, maxFreq, delta = 0, method = c("OLS", "WLS"), 
                              sigma = NULL) {
  method <- match.arg(method)
  n <- length(y)
  fit_matrix <- matrix(NA_real_, nrow = maxFreq, ncol = n)
  aic_vec <- numeric(maxFreq)
  bic_vec <- numeric(maxFreq)
  
  for (j in seq_len(maxFreq)) {
    if (method == "OLS") {
      fit <- haRmonics(y = y, method = "harmR", numFreq = j, delta = delta)$fitted
      ll <- log_like_OLS(sigma = stats::sd(y), y = y, fit = fit)
    } else {
      if (is.null(sigma)) stop("Sigma must be provided for WLS fitting")
      fit <- haRmonics(y = y, method = "wls_harmR", numFreq = j, delta = delta, 
                       sigma = sigma)$fitted
      ll <- log_like_WLS(sigma = sigma, y = y, fit = fit)
    }
    
    fit_matrix[j, ] <- fit
    n_params <- 2 * j + 1
    aic_vec[j] <- AIC(nparams = n_params, likelihood = ll)
    bic_vec[j] <- BIC(nparams = n_params, likelihood = ll, n = n)
  }
  
  list(fit = fit_matrix, aic = aic_vec, bic = bic_vec)
}

getSubOptimalFit <- function(x, lenPeriod, delta, fixedFreq, 
                             method = c("OLS", "WLS"), sigma=NULL,
                             var_method=c("standard", "robust-mad", "robust-Qn")) {
  
  method <- match.arg(method)
  var_method <- match.arg(var_method)
  
  x_mat <- vecToMatrix(x = x, lenPeriod = lenPeriod)
  n_rows <- nrow(x_mat)
  n_cols <- ncol(x_mat)
  
  if(method == "OLS"){
    Sigma <- sigma
    method_geoTS <- "harmR"
  } else {
    if(!is.null(sigma)){
      Sigma <- sigma
    } else {
      Sigma <- geoTS::hetervar(m=x_mat, lenPeriod = lenPeriod, method = var_method)
    }
    
    method_geoTS <- "wls_harmR"
  }
  
  # fit_list <- vector("list", length = n_rows)
  fit_mat <- matrix(NA_real_, nrow = n_rows, ncol = n_cols)
  # Fit models and compute AIC/BIC
  for (i in seq_len(n_rows)) {
    pixel <- x_mat[i, ]
    fit_mat[i,] <- geoTS::haRmonics(y=pixel, method = method_geoTS, 
                                    sigma = Sigma,
                                    numFreq = fixedFreq, delta = delta)$fitted
  }
  
  list(
    freqOptAIC = rep(fixedFreq, n_rows),
    freqOptBIC = rep(fixedFreq, n_rows),
    fitOptAIC = fit_mat,
    fitOptBIC = fit_mat,
    all_fit = fit_mat,
    sigma=Sigma
  )
  
}

getOptimalOLSFit <- function(x, lenPeriod, maxFreq, delta = 0, sigma=NULL, 
                             var_method=c("standard", "robust-mad", "robust-Qn")) {
  
  # x=y; lenPeriod=lenPeriod; maxFreq=maxFreq
  # delta = delta; sigma=sigma; var_method = var_method
  
  x_mat <- vecToMatrix(x = x, lenPeriod = lenPeriod)
  n_rows <- nrow(x_mat)
  n_cols <- ncol(x_mat)
  
  # Preallocate matrices
  aic_ols_mat <- matrix(NA_real_, nrow = n_rows, ncol = maxFreq)
  bic_ols_mat <- matrix(NA_real_, nrow = n_rows, ncol = maxFreq)
  fit_list <- vector("list", length = n_rows)
  
  # if(!is.null(sigma)){
  #   Sigma <- sigma
  # } else {
  #   Sigma <- geoTS::hetervar(m=x_mat, lenPeriod=lenPeriod, 
  #                            method=var_method)
  # }
  
  # Fit models and compute AIC/BIC
  for (i in seq_len(n_rows)) {
    pixel <- x_mat[i, ]
    fit_list[[i]] <- matrix(NA_real_, nrow = maxFreq, ncol = n_cols)
    
    ols_fits <- .fitHarmonicModel(y=pixel, maxFreq = maxFreq, method = "OLS")
    aic_ols_mat[i,] <- ols_fits$aic
    bic_ols_mat[i,] <- ols_fits$bic
    fit_list[[i]] <- ols_fits$fit
  }
  
  # Extract optimal fits
  opt_frq_ols_aic <- apply(aic_ols_mat, 1, which.min)
  opt_frq_ols_bic <- apply(bic_ols_mat, 1, which.min)
  
  opt_fit_ols_aic <- matrix(NA_real_, nrow = n_rows, ncol = n_cols)
  opt_fit_ols_bic <- matrix(NA_real_, nrow = n_rows, ncol = n_cols)
  
  for (k in seq_len(n_rows)) {
    opt_fit_ols_aic[k, ] <- fit_list[[k]][opt_frq_ols_aic[k], ]
    opt_fit_ols_bic[k, ] <- fit_list[[k]][opt_frq_ols_bic[k], ]
  }
  
  list(
    freqOptAIC = opt_frq_ols_aic,
    freqOptBIC = opt_frq_ols_bic,
    fitOptAIC = opt_fit_ols_aic,
    fitOptBIC = opt_fit_ols_bic,
    all_fit = fit_list,
    sigma=sigma
  )
}

getOptimalWLSFit <- function(x, lenPeriod, maxFreq, delta = 0, 
                             var_method=c("standard", "robust-mad", "robust-Qn"),
                             sigma=NULL) {
  
  
  # x=y; lenPeriod=lenPeriod; maxFreq=maxFreq
  # delta = delta; sigma=sigma; var_method = var_method  
  
  
  var_method <- match.arg(var_method)
  
  x_mat <- vecToMatrix(x = x, lenPeriod = lenPeriod)
  n_rows <- nrow(x_mat)
  n_cols <- ncol(x_mat)
  
  # Preallocate matrices
  aic_mat <- matrix(NA_real_, nrow = n_rows, ncol = maxFreq)
  bic_mat <- matrix(NA_real_, nrow = n_rows, ncol = maxFreq)
  fit_list <- vector("list", length = n_rows)
  
  if(!is.null(sigma)){
    Sigma <- sigma
  } else {
    Sigma <- geoTS::hetervar(m=x_mat, lenPeriod=lenPeriod, 
                             method=var_method)
  }
  
  # Fit models and compute AIC/BIC
  for (i in seq_len(n_rows)) {
    pixel <- x_mat[i, ]
    
    fit_list[[i]] <- matrix(NA_real_, nrow = maxFreq, ncol = n_cols)
    
    wls_fits <- .fitHarmonicModel(y=pixel, maxFreq = maxFreq, method = "WLS",
                                  sigma = Sigma)
    aic_mat[i,] <- wls_fits$aic
    bic_mat[i,] <- wls_fits$bic
    fit_list[[i]] <- wls_fits$fit
    
  }
  
  # Extract optimal fits
  opt_frq_aic <- apply(aic_mat, 1, which.min)
  opt_frq_bic <- apply(bic_mat, 1, which.min)
  
  opt_fit_aic <- matrix(NA_real_, nrow = n_rows, ncol = n_cols)
  opt_fit_bic <- matrix(NA_real_, nrow = n_rows, ncol = n_cols)
  
  for (k in seq_len(n_rows)) {
    opt_fit_aic[k, ] <- fit_list[[k]][opt_frq_aic[k], ]
    opt_fit_bic[k, ] <- fit_list[[k]][opt_frq_bic[k], ]
  }
  
  list(
    freqOptAIC = opt_frq_aic,
    freqOptBIC = opt_frq_bic,
    fitOptAIC = opt_fit_aic,
    fitOptBIC = opt_fit_bic,
    all_fit = fit_list,
    sigma=Sigma
  )
}

optimalHarmFit <- function(y, lenPeriod, maxFreq=10, 
                           method = c("OLS", "WLS"), delta=delta,
                           var_method=c("standard", "robust-mad", "robust-Qn"),
                           fixedFreq=NULL, sigma=NULL){
  
  # y=x; lenPeriod = lenPeriod; method = method
  # maxFreq = floor( (lenPeriod-1)/2 )
  # delta=delta; fixedFreq=fixedFreq; sigma=sigma
  
  method <- match.arg(method)
  var_method <- match.arg(var_method)
  
  if( method == "OLS" ){
    
    if(!is.null(fixedFreq)){
      output <- getSubOptimalFit(x=y, lenPeriod=lenPeriod, delta = delta, 
                                 fixedFreq=fixedFreq, sigma=sigma, var_method = var_method) 
    } else {
      output <- getOptimalOLSFit(x=y, lenPeriod=lenPeriod, maxFreq=maxFreq,
                                 delta = delta, sigma=sigma, var_method = var_method) 
    }
    
  }
  
  if( method == "WLS" ){
    
    if(!is.null(fixedFreq)){
      output <- getSubOptimalFit(x=y, lenPeriod=lenPeriod, delta = delta, 
                                 fixedFreq=fixedFreq, var_method=var_method, sigma=sigma)
    } else {
      output <- getOptimalWLSFit(x=y, lenPeriod=lenPeriod, maxFreq=maxFreq,
                                 delta = delta, var_method = var_method,
                                 sigma=sigma)
    }
    
  }
  
  output # this is a list
}

# --- Esta función devuelve una lista conteniendo:
# 1. freqOptAIC: vector con número óptimo de armónicos, selección de modelo 
# utilizada es AIC
# 2. freqOptBIC: vector con número óptimo de armónicos, selección de modelo 
# utilizada es BIC
# 3. fitOptAIC: matriz con ajuste, cada año es ajustado con el número óptimo de 
# armónicos, selección de modelo utilizada es AIC
# 4. fitOptBIC: matriz con ajuste, cada año es ajustado con el número óptimo de 
# armónicos, selección de modelo utilizada es BIC

getSmoothing <- function(x, lenPeriod, method=c("OLS", "WLS"), delta=0,
                         var_method = c("standard", "robust-mad", "robust-Qn"),
                         fixedFreq=NULL, sigma=NULL){
  
  
  # x=x; lenPeriod = frequency
  # method=method; delta=delta 
  # var_method = var_method; sigma=Sigma
  
  method <- match.arg(method)
  
  var_method <- match.arg(var_method)
  
  if(method=="OLS"){
    output <- optimalHarmFit(y=x, lenPeriod = lenPeriod, method = method, 
                             maxFreq = floor( (lenPeriod-1)/2 ),
                             delta=delta, fixedFreq=fixedFreq, sigma=sigma) # no need var_method
    
  } else {
    output <- optimalHarmFit(y=x, lenPeriod = lenPeriod, method = method, 
                             maxFreq = floor( (lenPeriod-1)/2 ),
                             delta=delta, var_method = var_method,
                             fixedFreq=fixedFreq, sigma=sigma)
  }
  
  output$all_fit <- NULL
  
  output
}

# ==============================================================================

fitHarmonic <- function(amp,pha,L,t){
  sum(sapply( 0:(length(amp)-1),
              function(k) amp[k+1] * cos( 2 * pi * k * t / L - pha[k+1]/(180/pi) )
  )
  )
}

getHarmonicFit <- function(m, samples, freqs, method=c("OLS", "WLS"),
                           sigma, delta) {
  
  method <- match.arg(method)
  
  if(method == "OLS"){
    method <- "harmR"
  } else {
    method <- "wls_harmR"
  }
  
  smooth_m_aug <- matrix(nrow=samples, ncol=nrow(m))
  for(i in 1:ncol(smooth_m_aug)){
    TEMP <- haRmonics(y=m[i,], method=method, sigma=sigma, numFreq=freqs[i], 
                      delta=delta)
    
    smooth_m_aug[,i] <- sapply(seq(0, (ncol(m)-1), length=samples),
                               function(s) fitHarmonic(amp=TEMP$amplitude,
                                                       pha=TEMP$phase,
                                                       t=s, L=ncol(m)))
  }
  
  smooth_m_aug
}

# ==============================================================================
# new_getFPCA (for testing): before getFPCA()
# ==============================================================================

# --- helpers

initializeFPCA <- function(DATA, basis, q.trend) {
  f.X <- basis$eigenvectorsQR[, 1:q.trend]
  f.Z <- basis$eigenvectorsQR[, (q.trend + 1):nrow(DATA)] %*%
    diag(1 / sqrt(basis$eigenvalues[(q.trend + 1):nrow(DATA)]))
  
  
  X.pop <- kronecker(matrix(1, ncol(DATA)), f.X)
  Z.pop <- kronecker(matrix(1, ncol(DATA)), f.Z)
  y <- c(as.matrix(DATA))
  One.Vec.All <- rep(1, length(y))
  
  est <- nlme::lme(y ~ -1 + X.pop,
                   random = list( One.Vec.All = nlme::pdIdent(~Z.pop - 1)),
                   correlation = NULL)
  
  fitted <- matrix(rep(est$fitted[1:nrow(DATA), 2], ncol(DATA)), nrow = nrow(DATA))
  residuals <- DATA - fitted
  
  list(est = est, residuals = residuals)
}

selectInitialEF <- function(residuals, k) {
  svd_res <- svd(t(residuals))
  ef <- svd_res$v[, 1:k]
  if (k == 1 && min(ef) < 0) ef <- -ef
  return(ef)
}

# Safe LME wrapper
safe_lme <- function(...) {
  tryCatch(nlme::lme(...), error = function(e) {
    message("lme failed: ", conditionMessage(e))
    return(NULL)
  })
}

# --- still tryCatch-part needs to be incorporated 
updateEFStep_tryCatch <- function(DATA, basis, ef, k, q.ef, nd, corr){
  
  n <- nrow(DATA)
  p <- ncol(DATA)
  y <- c(as.matrix(DATA))
  casesId <- rep(seq_len(p), each = n)
  
  # Population-level design matrices
  f.X <- basis$eigenvectorsQR[, 1:q.ef]
  f.Z <- basis$eigenvectorsQR[, (q.ef + 1):n] %*%
    diag(1/sqrt(basis$eigenvalues[(q.ef + 1):n]))
  X.pop <- kronecker(matrix(1, nrow = p), f.X)
  X.pop.df <- as.data.frame(X.pop)
  names(X.pop.df) <- paste0("Xpop_", seq_len(ncol(X.pop)))
  Z.pop <- kronecker(matrix(1, nrow = p), f.Z)
  Z.pop.df <- as.data.frame(Z.pop)
  names(Z.pop.df) <- paste0("Zpop_", seq_len(ncol(Z.pop)))
  Z.cases.ef <- kronecker(matrix(1, nrow=p), ef)
  Z.cases.df <- as.data.frame(Z.cases.ef)
  names(Z.cases.df) <- paste0("Zcases_", seq_len(ncol(Z.cases.ef)))
  One.Vec.All <- rep(1, length(y))
  
  # df <- data.frame(
  #   y = c(as.matrix(DATA)),
  #   One.Vec.All = rep(1, nrow(DATA) * ncol(DATA)),
  #   casesId = factor(rep(seq_len(ncol(DATA)), each = nrow(DATA)))
  # )
  # df <- cbind(df, X.pop.df, Z.pop.df, Z.cases.df)
  # 
  # fixed_formula <- as.formula(paste("y ~ -1 +", paste(names(X.pop.df), collapse = " + ")))
  # random_formula <- list(
  #   One.Vec.All = nlme::pdIdent(as.formula(paste("~", paste(names(Z.pop.df), collapse = " + ")))),
  #   casesId = nlme::pdDiag(as.formula(paste("~", paste(names(Z.cases.df), collapse = " + "))))
  # )
  
  # Initial mixed model fit
  # est <- safe_lme(
  #   fixed = fixed_formula,
  #   random = random_formula,
  #   correlation = corr,
  #   data = df
  # )
  
  est <- nlme::lme(y ~ -1 + X.pop,
                   random = list(One.Vec.All = nlme::pdIdent(~Z.pop - 1),
                                 casesId = nlme::pdDiag(~Z.cases.ef - 1)),
                   correlation = NULL)
  
  # if (is.null(est)) {
  #   return(list(ef = ef, alpha = matrix(0, p, k), converged = FALSE, 
  #               warnings = "Initial lme failed"))
  # }
  
  sigma2.e <- est$sigma^2
  sigma2.b.pop <- (est$sigma^2) *
    exp(2 * unlist(est$modelStruct)[k + 1])
  lambda <- sigma2.e/sigma2.b.pop
  
  alpha <- t(est$coefficients$random$casesId)
  # if (k == 1) alpha <- matrix(alpha, ncol = 1)
  
  fi <- matrix(est$fitted[, 3], nrow=n, ncol=p)
  
  # cat("ef:", dim(ef), "\n")
  # cat("alpha:", dim(alpha), "\n")
  
  di <- ef %*% alpha
  f <- fi - di
  # si <- NULL
  # ei <- DATA - f
  ef.c <- NULL # matrix(0, nrow = n, ncol = k) # NULL
  # ef.d1.c <- NULL
  # ef.d2.c <- NULL
  thetaf.c <- NULL
  warnings <- character()
  
  if (k == 1) {
    alpha <- matrix(alpha, ncol = 1)
  } else {
    alpha <- matrix(alpha, ncol = ncol(alpha))
    alpha <- t(alpha)
  }
  
  for ( i in seq_len(k) ) {
    # if (k == 1) {
    #   di.m <- 0
    # } else {
    #   di.m <- ef[, -i] %*% t(alpha[, -i])
    # }
    
    di.m <- if (k == 1) 0 else ef[, -i] %*% t(alpha[, -i])
    
    X.ef <- NULL
    Z.ef <- NULL
    N.ef <- NULL
    D.ef <- NULL
    
    for ( j in seq_len(p) ) {
      # basisd <- basis
      basisd <- basis
      alphamat <- diag(rep(alpha[j, i], nrow(DATA)))
      X.ef.c <- alphamat %*% basisd$eigenvectorsQR[, 1:q.ef]
      X.ef <- dbind(X.ef, X.ef.c)
      Z.ef.c <- alphamat %*% basisd$eigenvectorsQR[, (q.ef + 1):nd] %*%
        diag(1/sqrt(basisd$eigenvalues[(q.ef + 1):nd]))
      Z.ef <- dbind(Z.ef, Z.ef.c)
      D.ef.c <- diag(basisd$eigenvalues[1:nd])
      D.ef <- dbind(D.ef, D.ef.c)
      # N.ef.c <- alphamat %*% basisd$eigenvectorsQR[, 1:nd]
      # N.ef <- dbind(N.ef, N.ef.c)
    }
    
    r <- DATA - f - di.m
    r <- c(as.matrix(r))
    
    # df.r <- data.frame(
    #   r = r, #c(as.matrix(DATA)),
    #   X.ef = X.ef,
    #   Z.ef = Z.ef,
    #   # Z.cases.ef = Z.cases.ef,
    #   One.Vec.All = One.Vec.All, #rep(1, nrow(DATA) * ncol(DATA)),
    #   # casesId = casesId # factor(rep(seq_len(ncol(DATA)), each = nrow(DATA)))
    # )
    
    if (is.null(corr)) {
      # est.r <- safe_lme(
      #   fixed = r ~ -1 + X.ef,
      #   random = list(One.Vec.All = nlme::pdIdent(~Z.ef - 1)),
      #   correlation = NULL,
      #   data = df.r
      # )
      est.r <- nlme::lme(r ~ -1 + X.ef,
                         random = list(One.Vec.All = nlme::pdIdent(~Z.ef - 1)),
                         correlation = NULL)
    } else {
      # est.r <- safe_lme(
      #   fixed = r ~ -1 + X.ef,
      #   random = list(One.Vec.All = nlme::pdIdent(~Z.ef - 1)),
      #   correlation = corr,
      #   data = df.r
      # )
      est.r <- nlme::lme(r ~ -1 + X.ef,
                         random = list(One.Vec.All = nlme::pdIdent(~Z.ef - 1)),
                         correlation = corr)
    }
    
    sigma2.e <- est.r$sigma^2
    sigma2.b <- (est.r$sigma^2) * exp(2 * unlist(est.r$modelStruct))
    lambda <- sigma2.e/sigma2.b
    
    # X.ef <- basisd$eigenvectorsQR[, 1:q.ef]
    # Z.ef <- basisd$eigenvectorsQR[, (q.ef + 1):nd] %*%
    #   diag(1/sqrt(basisd$eigenvalues[(q.ef + 1):nd]))
    N.ef <- basisd$eigenvectorsQR[, 1:nd]
    D.ef <- diag(basisd$eigenvalues[1:nd])
    
    # add1 <- 0
    # add2 <- 0
    
    add1 <- matrix(0, nrow = nd, ncol = nd)
    add2 <- matrix(0, nrow = nd, ncol = 1)
    
    # for (l in 1:p) {
    #   r.c <- matrix(r, ncol = ncol(DATA))[, l]
    #   add1 <- add1 + (alpha[l, i]^2) *
    #     diag(ncol(N.ef)) + (lambda/ncol(DATA)) * D.ef
    #   add2 <- add2 + (alpha[l, i]) * (t(N.ef) %*% r.c)
    # }
    
    for (l in seq_len(p)) {
      rj <- matrix(r, ncol = p)[, l]
      add1 <- add1 + alpha[l, i]^2 * diag(ncol(N.ef)) + (lambda / p) * D.ef
      add2 <- add2 + alpha[l, i] * (t(N.ef) %*% rj)
    }
    
    # Safe solve
    # theta <- tryCatch(solve(add1, add2), error = function(e) {
    #   warnings <<- c(warnings, paste("solve failed for component", i))
    #   rep(0, nd)
    # })
    
    # ef.c[,i] <- N.ef %*% theta
    
    ef.c <- cbind(ef.c, N.ef %*% (solve(add1) %*% add2))
    thetaf.c <- cbind(thetaf.c, solve(add1) %*% add2)
    
    # theta <- solve(add1) %*% add2
    # ef <- N.ef %*% theta
  }
  
  if( k == 1 ){
    ef.c <- ef.c / sqrt( sum(ef.c^2) )
  } else {
    thetaf.c <- qr.Q( qr(thetaf.c)  )
    ef.c <- N.ef %*% thetaf.c
    # qr_theta <- qr(theta)
    # ef.c <- N.ef %*% qr.Q(qr_theta)
  }
  
  # list(ef=ef.c, theta=thetaf.c, sigma=sigma2.b)
  
  # Convergence check
  conv <- spectralnorm(ef - ef.c)
  converged <- conv < 0.05
  
  list(ef = ef.c, 
       alpha = alpha, 
       converged = converged, 
       # warnings = warnings, Este argumento tendrá sentido cuando complete los tryCatch de esta función
       sigma=sigma2.b)
}

# ---
updateComponentsIteratively <- function(DATA, basis, ef_init, k, q.ef, nd, corr, 
                                        max_iter = ncol(DATA) * 10) {
  ef <- ef_init
  convergence <- numeric()
  for (iter in seq_len(max_iter)) {
    message(paste("Iteration", iter))
    result <- updateEFStep_tryCatch(DATA=DATA, basis=basis, ef=ef, k=k, 
                                    q.ef=q.ef, nd=nd, corr=corr)
    convergence[iter] <- spectralnorm(ef - result$ef)
    
    if ( result$converged ) {
      message("Convergence achieved")
      # cat("sigma2.b: ", result$sigma, "\n")
      return(result)
    }
    
    ef <- result$ef
  }
  stop("No convergence achieved")
  # result
}

finalizeFPCA <- function(DATA, basis, ef, corr, 
                         confiBand=FALSE, alpha_cb, sigma, k, q.trend){
  
  n <- nrow(DATA)
  
  f.X <- basis$eigenvectorsQR[, 1:q.trend]
  f.Z <- basis$eigenvectorsQR[, (q.trend + 1):nrow(DATA)] %*%
    diag(1 / sqrt(basis$eigenvalues[(q.trend + 1):nrow(DATA)]))
  
  X.pop <- kronecker(matrix(1, ncol(DATA)), f.X)
  Z.pop <- kronecker(matrix(1, ncol(DATA)), f.Z)
  y <- c(as.matrix(DATA))
  
  f.Z.ef <- ef
  Z.cases.ef <- kronecker(matrix(1, nrow = ncol(DATA)), f.Z.ef)
  
  One.Vec.All <- rep(1, length(y))
  casesId <- rep(1:ncol(DATA), each = nrow(DATA))
  
  if (is.null(corr)) {
    corcoefs <- "Model fitted with white noise remainder"
    
    # What Z.cases.ef is intended here? Notice that the last one was created
    # during the last iteration above
    # What Z.pop is intended here? Note that the last one was created right 
    # before entering into the for-loop above
    # Shouldnt Z.pop and Z.cases.ef be created at the same level
    est <- nlme::lme(y ~ -1 + X.pop, 
                     random = list(One.Vec.All = nlme::pdIdent(~Z.pop - 1), 
                                   casesId = nlme::pdDiag(~Z.cases.ef - 1)), 
                     correlation = NULL)
  } else {
    est <- nlme::lme(y ~ -1 + X.pop, 
                     random = list(One.Vec.All = nlme::pdIdent(~Z.pop - 1), 
                                   casesId = nlme::pdDiag(~Z.cases.ef - 1)), 
                     correlation = corr)
  }
  
  sigma2.e <- est$sigma^2
  sigma2.b.pop <- (est$sigma^2) * exp(2 * unlist(est$modelStruct)[k + 1])
  lambda <- sigma2.e/sigma2.b.pop
  cr.Zef <- est$coefficients$random$casesId
  alpha <- cr.Zef
  
  fi <- matrix(est$fitted[, 3], nrow=nrow(DATA), ncol=ncol(DATA))
  di <- ef %*% t(alpha) # iter_result$ef %*% t(alpha)
  f <- fi - di
  
  if( confiBand ){
    nf <- ncol(X.pop)
    nr <- ncol(Z.pop)
    beta <- est$coefficients$fixed[1:nf]
    mu <- est$coefficients$random$One.Vec.All[1:nr]
    
    # originally there was sigma2.b
    samples.f <- t(MASS::mvrnorm(n = 1e4, 
                                 mu = f.X%*%beta + f.Z%*%mu, 
                                 Sigma = (sigma/(n^2))*f.Z%*%t(f.Z)+(sigma2.e/(n^2))*diag(n)))
    
    f.ucb <- apply(samples.f, 1, stats::quantile, 1-alpha_cb/2)
    
    f.lcb <- apply(samples.f, 1, stats::quantile, alpha_cb/2)
    
  } else {
    f.ucb <- NULL
    f.lcb <- NULL
  }
  
  list(est = est, f = f[, 1], upperConfBand = f.ucb, lowerConfBand = f.lcb)
}

runFPCA <- function(DATA, basis, k, corr = NULL, num_times, confiBand = FALSE, alpha_cb = 0.05) {
  nd <- floor(nrow(DATA) / 8)
  q <- c(2, 2)
  
  message("STEP 1: Initial Model Estimation")
  init <- initializeFPCA(DATA=DATA, basis=basis, q.trend = q[1]) #returns est and residuals
  
  message("STEP 2: SVD and Initial EF Selection")
  ef <- selectInitialEF(residuals = init$residuals, k = k) # returns ef
  
  message("STEP 3: Iterative Component Update")
  iter_result <- updateComponentsIteratively(DATA= DATA, basis = basis, 
                                             ef_init = ef, k = k, q.ef = q[2], 
                                             nd = nd, corr = corr) # returns ef and theta
  
  message("STEP 4: Final Estimation and Confidence Bands")
  final <- finalizeFPCA(DATA = DATA, basis = basis, ef = iter_result$ef, corr = corr, 
                        confiBand = confiBand, alpha_cb = alpha_cb, sigma = iter_result$sigma, 
                        k=k, q.trend = q[1])
  
  final$converged <- iter_result$converged
  
  return(final)
}

FPCA_tryCatch <- function(DATA, k, corr = NULL, basis, 
                          confiBand=FALSE, alpha) {
  
  if( missing(k) ){
    stop("k must be an integer between 1 and the sample size")
  }
  
  df_DATA <- data.frame(DATA)
  
  if( ncol(df_DATA) < 2 ){
    stop("Data matrix must contain at least 2 columns")
  }
  
  if( missing(basis) ){
    basis <- drbasis(nn = nrow(df_DATA), qq = 2)
    message("STEP 0 * Computing DR Basis")
  } else {
    message("STEP 0 * Loading DR Basis")
  }
  
  # still missing to incorporate tryCatch to runFPCA
  auxiliary <- show_condition(runFPCA(DATA=DATA, basis=basis, k=k,
                                      corr=corr, num_times=nrow(DATA), 
                                      confiBand=confiBand, alpha_cb=alpha))
  
  
  output <- list()
  if(inherits(auxiliary, "character")){
    # output <- list()
    output$status <- "Failure: inspect runFPCA()"
    output$converged <- NA
    output$est <- NA
    output$f <- NA
    output$upperCB <- NA
    output$lowerCB <- NA
  } else {
    # output <- list()
    output$status <- "Success"
    # --- added Oct 23, 2025
    output$converged <- auxiliary$converged
    output$est <- auxiliary$est
    output$f <- auxiliary$f
    # --- added July 10, 2024
    output$upperCB <- auxiliary$upperConfBand
    output$lowerCB <- auxiliary$lowerConfBand
  }
  
  list(est = output$est, f = output$f, 
       status=output$status,
       converged=output$converged,
       upperCB = output$upperCB, lowerCB = output$lowerCB)
  
}

getFPCA <- function(series, seriesByCluster, clusterSize, k, mAug, basis,
                    corr, confiBand=FALSE, alpha){
  
  flag <- FALSE # se usaron menos de 17 series
  
  if(is.null(series)){
    seriesInCluster <- lapply(1:length(unique(seriesByCluster)),
                              function(s) which(seriesByCluster == s))
    
    if( length(seriesInCluster[[1]]) >= clusterSize ) {
      SERIES <- seriesInCluster[[1]]
    }
    
    if( length(seriesInCluster[[2]]) >= clusterSize ) {
      SERIES <- seriesInCluster[[2]]
    }
    
    AUX <- ifelse(any(table(seriesByCluster) >= clusterSize), TRUE, FALSE) # No dominating cluster
    if( !AUX ) {
      # SERIES <- 1:22
      SERIES <- 1:length(seriesByCluster)
      flag <- TRUE
    }
    
  } else {
    SERIES <- series
    flag <- ifelse( length(SERIES) == ncol(mAug), TRUE, FALSE )
  }
  
  # output <- runFPCA(DATA=mAug[,SERIES], k=k, basis=basis,
  #                         corr=corr, confiBand=confiBand, alpha=alpha)
  
  output <- FPCA_tryCatch(DATA=mAug[,SERIES], k=k, basis=basis,
                          corr=corr, confiBand=confiBand, alpha=alpha)
  
  # if(output$status=="Failure"){
  #   # --- Commented on July 18, 2024
  #   # --- FPCA_tryCatch() already takes care of these conditionals
  #   #   output <- list()
  #   #   output$f <- NA
  #   #   # status <- "Failure"
  #   flag <- NA
  # }
  
  # list(fpca=output$f, usedTotal=flag, status=status)
  list(
    fpca=output$f, 
    fpca_upperCB=output$upperCB,
    fpca_lowerCB=output$lowerCB,
    usedTotal=flag, 
    usedSeries=SERIES, 
    status=output$status,
    mixedmodel_converged=output$converged
  )
}
# ==============================================================================

# ==============================================================================
# getPhenodates: before getPhenoDatesUpdate()
# ==============================================================================

# --- functions associated with getPhenodates
round_half_up <- function(x) {
  ifelse(x %% 1 < 0.5, floor(x), ceiling(x))
}

whatToDo <- function(x){
  switch(class(x),
         "list" = "list",
         "character" = NA)
}

# --- phenoDatesConstraints: before check_phenoCond() 
phenoDatesConstraints <- function(GU_Mat, SoS_EoS, Sen, Dor, f2der) {
  
  # SoS_EoS=SoS_EoS; GU_Mat=GU_Mat; Sen=Sen
  # Dor=Dorm; f2der=fbiprime
  # 
  # GU_Mat
  # SoS_EoS
  # GU_Mat
  # Sen
  # SoS_EoS
  # Dor
  
  # whatToDo <- function(x){
  #   # x = GU_Mat
  #   switch(class(x),
  #          "list" = "list",
  #          "character" = NA)
  # }
  
  # whatToDo(GU_Mat)
  
  # Extract key phenological markers
  x_vals <- list(
    GU  = ifelse( whatToDo(GU_Mat) == "list", ifelse(length(GU_Mat$max)==0, NA, GU_Mat$max), NA ),
    SoS = ifelse( whatToDo(SoS_EoS) == "list", ifelse(length(SoS_EoS$max)==0, NA, SoS_EoS$max), NA),
    Mat = ifelse( whatToDo(GU_Mat) == "list", ifelse(length(GU_Mat$min)==0, NA, GU_Mat$min), NA),
    Sen = ifelse( whatToDo(Sen) == "list", ifelse(length(Sen$x_opt) ==0, NA, Sen$x_opt), NA),
    EoS = ifelse( whatToDo(SoS_EoS) == "list", ifelse(length(SoS_EoS$min)==0, NA, SoS_EoS$min), NA),
    Dor = ifelse( whatToDo(Dor) == "list", ifelse(length(Dor$x_opt) ==0, NA, Dor$x_opt), NA)
  )
  
  # Extract key phenological markers
  # x_vals <- list(
  #   GU   = ifelse(length(GU_Mat$max)==0, NA, GU_Mat$max),
  #   SoS  = ifelse(length(SoS_EoS$max)==0, NA, SoS_EoS$max), # SoS_EoS$max,
  #   Mat  = ifelse(length(GU_Mat$min)==0, NA, GU_Mat$min), #GU_Mat$min,
  #   Sen  = ifelse(Sen == "ERROR", NA, ifelse(length(Sen$x_opt) ==0, NA, Sen$x_opt)),   # or: Sen$mins[which.max(f2der(Sen$mins))]
  #   EoS  = ifelse(length(SoS_EoS$min)==0, NA, SoS_EoS$min), # SoS_EoS$min,
  #   Dor  = ifelse(length(Dor$x_opt) == 0, NA, Dor$x_opt)  #Dor$x_opt    # or: Dorm$maxs[which.min(f2der(Dorm$maxs))]
  # )
  
  # Apply rounding
  params <- lapply(x_vals, round_half_up)
  
  # Count missing values
  num_na <- sum(is.na(unlist(params)))
  
  # Assign flag based on completeness
  flag <- switch(as.character(num_na),
                 "0" = "Full",
                 "1" = "Partial-5",
                 "2" = "Partial-4",
                 "3" = "Partial-3",
                 "4" = "Partial-2",
                 "5" = "Partial-1",
                 "6" = "Failure",
                 "Unknown")
  
  list(params = params, flag = flag)
}

# Special care is taken on Sen and Dorm as these parameters are not
# ensured to exists; see Theorem in paper.
getPhenoDates <- function(fit, L=365, interval=seq(1,L,length=L)){
  
  # fit=fit
  
  fzero <- ndvi_derivatives(amp=fit$amplitude, pha=fit$phase, degree=0, L=L)
  
  fprime <- ndvi_derivatives(amp=fit$amplitude, pha=fit$phase, degree=1, L=L)
  
  fbiprime <- ndvi_derivatives(amp=fit$amplitude, pha=fit$phase, degree=2, L=L)
  
  fthrprime <- ndvi_derivatives(amp=fit$amplitude, pha=fit$phase, degree=3, L=L)
  
  ffthprime <- ndvi_derivatives(amp=fit$amplitude, pha=fit$phase, degree=4, L=L)
  
  GU_Mat <- global_min_max(f=fbiprime, f1der=fthrprime, f2der=ffthprime, D=interval)
  
  Sen <- show_condition(local_min_max(f=fbiprime, f1der=fthrprime, f2der=ffthprime, 
                                      what="min", x0=GU_Mat$min, D=interval))
  
  SoS_EoS <- global_min_max(f=fprime, f1der=fbiprime, f2der=fthrprime, D=interval)
  
  Dorm <- show_condition(local_min_max(f=fbiprime, f1der=fthrprime, f2der=ffthprime, what="max", 
                                       x0=GU_Mat$max, D=interval))
  
  parPheno <- phenoDatesConstraints(SoS_EoS=SoS_EoS, GU_Mat=GU_Mat, Sen=Sen, 
                                    Dor=Dorm, f2der=fbiprime)
  
  list(dates=unlist(parPheno$params),
       status_phenodates=parPheno$flag, #status_phenodates,
       zder=fzero, fder=fprime, sder=fbiprime, thrder=fthrprime, fthder=ffthprime)
}
# ==============================================================================

phenopar_tryCatch <- function(x, frequency=23, 
                              method=c("OLS", "WLS"),
                              modelSelection=c("AIC", "BIC"), 
                              sigma=NULL, 
                              fixedFreq=NULL,
                              # numFreq, 
                              delta=0, 
                              var_method=c("standard", "robust-mad", "robust-Qn"), 
                              distance, series, 
                              clusterSize=0.75,
                              samples, basis, 
                              corr=NULL, k, 
                              trace=FALSE, 
                              confiBand=FALSE, 
                              alpha=0.05){
  
  # x=data_pixel; frequency=12; method="OLS"
  # modelSelection="AIC"; sigma=NULL; fixedFreq=NULL
  # delta=0; var_method="standard"; distance="dtw2"; series=NULL;
  # clusterSize=0.75; samples=length(BASIS[["x"]]); basis=BASIS; corr=NULL
  # k=2; trace=FALSE; confiBand=FALSE; alpha=0.05
  
  method <- match.arg(method)
  
  modelSelection <- match.arg(modelSelection)
  
  var_method <- match.arg(var_method)
  
  xMat <- vecToMatrix(x=x, lenPeriod=frequency)
  dominatingClusterSize <- as.integer(clusterSize * nrow(xMat))
  
  if(method == "OLS"){
    
    if( !is.null(sigma) ){ 
      if( length(sigma) != 1 ) stop("length of 'sigma' must be equal to 1") else Sigma <- sigma
    } else {
      Sigma <- sigma
    }
    method_geoTS <- "harmR"
  } else {
    
    if( !is.null(sigma) ){
      if(length(sigma)!=frequency) stop("length of 'sigma' must be equal to 'frequency'") else Sigma <- sigma
    } else {
      Sigma <- geoTS::hetervar(m=xMat, lenPeriod = frequency, method = var_method)
    }
    method_geoTS <- "wls_harmR"
  }
  
  if(!is.null(fixedFreq)){
    mat_smooth_sigma <- getSmoothing(x=x, lenPeriod = frequency, 
                                     method=method, delta=delta, 
                                     var_method = var_method,
                                     fixedFreq = fixedFreq, sigma=Sigma)
  } else {
    mat_smooth_sigma <- getSmoothing(x=x, lenPeriod = frequency, 
                                     method=method, delta=delta, 
                                     var_method = var_method,
                                     sigma=Sigma)
  }
  
  if( modelSelection == "AIC" ){
    matrixToSmooth <- mat_smooth_sigma$fitOptAIC
    freqsToSmooth <- mat_smooth_sigma$freqOptAIC
  }
  
  if( modelSelection == "BIC" ){
    matrixToSmooth <- mat_smooth_sigma$fitOptBIC
    freqsToSmooth <- mat_smooth_sigma$freqOptBIC
  }
  
  clust_distance <- tsclusters_centroid(m = matrixToSmooth, seed = 11,
                                        distance = distance, trace = trace)
  
  mat_augSmooth <- getHarmonicFit(m=matrixToSmooth, 
                                  samples = samples,
                                  sigma = mat_smooth_sigma$sigma, 
                                  delta=delta, 
                                  freqs = freqsToSmooth)
  
  x_fpca <- getFPCA(series=series, seriesByCluster=clust_distance@cluster, 
                    clusterSize=dominatingClusterSize, 
                    k=k, mAug=mat_augSmooth, 
                    basis=basis, corr=corr, confiBand=confiBand, alpha=alpha)
  
  if(x_fpca$status=="Failure: inspect runFPCA()"){
    fit <- list()
    fit$a.coef <- NA
    fit$b.coef <- NA
    fit$amplitude <- NA
    fit$phase <- NA
    fit$status <- paste(x_fpca$status, " try increasing 'samples'")
    fit$mixedmodel <- NA
    
    phenoDates <- list()
    phenoDates$zder <- NA
    phenoDates$fder <- NA
    phenoDates$sder <- NA
    phenoDates$thrder <- NA
    phenoDates$fthder <- NA
    
    # Commented on Oct 23, 2025
    phenoDates$status <- NA # status
    # message("FPCA model non inverted, try increasing 'samples'")
    
    Sigma_geoTS <- Sigma
    freqsFinalFit <- NA
  } else {
    
    if( method_geoTS == "wls_harmR" ){
      Sigma_geoTS <- apply(t(mat_augSmooth), 2, stats::sd)
    } else {
      Sigma_geoTS <- Sigma
    }
    
    lp <- length(x_fpca$fpca)
    toGet_optFreq_finalFit <- optimalHarmFit(y=x_fpca$fpca, 
                                             lenPeriod = lp, 
                                             maxFreq = floor( (lp-1)/2 ),
                                             method=method,
                                             delta=delta,
                                             var_method = var_method,
                                             fixedFreq=fixedFreq, 
                                             sigma=Sigma_geoTS)
    
    if( modelSelection == "AIC" ){
      freqsFinalFit <- toGet_optFreq_finalFit$freqOptAIC
    }
    
    if( modelSelection == "BIC" ){
      freqsFinalFit <- toGet_optFreq_finalFit$freqOptBIC
    }
    
    fit <- geoTS::haRmonics(y=x_fpca$fpca, numFreq = freqsFinalFit, 
                            method = method_geoTS, sigma = Sigma_geoTS,
                            delta = delta)
    
    phenoDates <- getPhenoDates(fit=fit)
    
    fit$status <- x_fpca$status
    fit$mixedmodel <- x_fpca$mixedmodel_converged
    
  }
  
  # if(phenoDates$status_phenodates == "Full"){
  #   status <- "Success"
  # }
  # 
  # if(unlist(strsplit(phenoDates$status_phenodates, "-"))[1] == "Partial"){
  #   status <- "Partial"
  # }
  
  list(
    x=x,
    freq=frequency,
    # sigma=Sigma_geoTS,
    sigma=mat_smooth_sigma$sigma,
    x_smooth=mat_smooth_sigma,
    m_aug_smooth=t(mat_augSmooth),
    clustering=clust_distance,
    usedTotal=x_fpca$usedTotal,
    series=x_fpca$usedSeries,
    clusterSize=clusterSize,
    dominatingClusterSize=length(x_fpca$usedSeries),
    fpca=x_fpca$fpca, 
    fpca_upperCB=x_fpca$fpca_upperCB,
    fpca_lowerCB=x_fpca$fpca_lowerCB,
    fpca_harmfit_params=list(a.coef=fit$a.coef, b.coef=fit$b.coef, 
                             amplitude=fit$amplitude, phase=fit$phase),
    fpca_fun_0der=phenoDates$zder,
    fpca_fun_1der=phenoDates$fder,
    fpca_fun_2der=phenoDates$sder,
    fpca_fun_3der=phenoDates$thrder,
    fpca_fun_4der=phenoDates$fthder,
    phenoparams=phenoDates$dates,
    # status=status
    # optimal
    mixedmodel_status=fit$status,
    mixedmodel_inverted=fit$mixedmodel,
    critical_points_fpca=phenoDates$status_phenodates,
    optimal_num_harms=freqsToSmooth[x_fpca$usedSeries],
    optimal_harms_fpca=freqsFinalFit
  )
}

# ==============================================================================

phenopar_polygon_tryCatch <- function(data, product, frequency, method, modelSelection,
                                      sigma, var_method,
                                      fixedFreq, delta, distance, series, clusterSize, samples,
                                      basis, corr, k, confiBand, alpha, numCores,
                                      objectsToSave, dirToSave,
                                      reportFileBaseName, trace) {
  
  reportFileName <- paste0( dirToSave, "/", reportFileBaseName, ".txt" )
  file.create(path = reportFileName, showWarnings = FALSE)
  write( "--- SEPHORA began at ---", file = reportFileName,
         append = TRUE )
  write( as.character(Sys.time()[1]), file = reportFileName,
         append = TRUE )
  
  dataPOLYGON <- data
  
  kluster <- parallel::makeCluster(spec=numCores, outfile="")
  registerDoParallel(kluster)
  
  output <- foreach(i=1:nrow(dataPOLYGON), #.combine="rbind",
                    .export=c("vecFromData", "vecToMatrix", "fill_initialgap_MOD13Q1",
                              "phenopar_tryCatch",
                              "AIC", "BIC", "log_like_OLS", "log_like_WLS",
                              ".fitHarmonicModel", "getSubOptimalFit", "getOptimalOLSFit",
                              "getOptimalWLSFit", "getSmoothing",
                              "tsclusters_centroid", "getHarmonicFit",
                              "getFPCA", "FPCA_tryCatch", "runFPCA",
                              "finalizeFPCA", "updateComponentsIteratively",
                              "updateEFStep_tryCatch", "selectInitialEF", "initializeFPCA",
                              "show_condition", 
                              "fitHarmonic", "whatToDo",
                              "spectralnorm", "dbind",
                              "global_min_max", "local_min_max",
                              "round_half_up", "phenoDatesConstraints", "getPhenoDates",
                              "ndvi_derivatives", "what_objects"),
                    .packages=c("dtwclust", "geoTS", "bigmemory",
                                "rootSolve")) %dopar% {
                                  
                                  x <- vecFromData(data = dataPOLYGON, numRow = i,
                                                   product = product, lenPeriod=frequency)
                                  
                                  get_phenoparams <- phenopar_tryCatch(x=x$vec,
                                                                       frequency=frequency,
                                                                       method=method,
                                                                       modelSelection = modelSelection,
                                                                       sigma=sigma,
                                                                       var_method = var_method,
                                                                       fixedFreq = fixedFreq,
                                                                       delta=delta,
                                                                       distance=distance,
                                                                       series = series,
                                                                       clusterSize=clusterSize,
                                                                       samples=samples,
                                                                       basis=basis,
                                                                       corr=corr,
                                                                       k=k,
                                                                       trace=trace,
                                                                       confiBand=confiBand,
                                                                       alpha=alpha) # missing series, confiBand and alpha
                                  
                                  s <- what_objects(x=get_phenoparams,
                                                    whatToExtract=objectsToSave)
                                  
                                  if( i %% 50 == 0 ){
                                    texto <- paste0("Working on ROW: ", i)
                                    write(texto, file = reportFileName, append = TRUE)
                                  }
                                  
                                  return(s)
                                }
  stopCluster(kluster)
  
  write( as.character(Sys.time()[1]), file = reportFileName, append = TRUE)
  write(paste("OUTPUT will be saved at ", dirToSave,  " shortly"),
        file = reportFileName, append = TRUE)
  write( "--- SEPHORA ended at ---", file = reportFileName, append = TRUE)
  write( as.character(Sys.time()[1]), file = reportFileName, append = TRUE)
  
  # save(output, file = paste0(dirToSave, "/",
  #                            tools::file_path_sans_ext(basename(path)),
  #"_phenoparams.RData"))
  
  output
}

# ==============================================================================

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# --- FUNCTIONS & OBJECTS used to define and handle sephora-class objects
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

globalVariables(c('MONTHS', 'i', 'DoY', 'cluster',
                  'values', 'y', 'years', 'validObjects'),
                package = "sephora")

validObjects <- c("x", "freq", "sigma", "xSmooth", "maugSmooth", 
                  "usedTotal", "series", "clusterSize", "dominatingClusterSize", 
                  "clustering",  
                  "fpca", "fpca_lowerCB", "fpca_upperCB",
                  "fpca_harmfit_params",
                  "fpcaFun0Der", "fpcaFun1Der",
                  "fpcaFun2Der", "fpcaFun3Der",
                  "fpcaFun4Der", "phenoparams",
                  "mixedmodel_status", "mixedmodel_inverted",
                  "startYear", "endYear",
                  "optimal_num_harms", "optimal_harms_fpca", "critical_points")

what_objects <- function(x, whatToExtract){
  
  output <- vector(mode="list", length=length(whatToExtract))
  output <- lapply(whatToExtract, function(s) x[[s]] )
  names(output) <- whatToExtract
  
  output
}

# --- Added on Dec 21, 2023
# --- Modified on Aug 23, 2024

toSephoraClass <- function(x, startYear, endYear){
  
  # x=output 
  # startYear=startYear
  # endYear=endYear
  
  out <- list(
    x=x$x,
    startYear=startYear,
    endYear=endYear,
    freq=x$freq,
    sigma=x$sigma,
    xSmooth=x$x_smooth[1:4],
    maugSmooth=x$m_aug_smooth,
    usedTotal=x$usedTotal,
    series=x$series,
    clustering=x$clustering,
    clusterSize=x$clusterSize,
    dominatingClusterSize=x$dominatingClusterSize,
    fpca=x$fpca,
    fpcaLowerCB=x$fpca_lowerCB,
    fpcaUpperCB=x$fpca_upperCB,
    fpcaHarmFitParams = x$fpca_harmfit_params,
    fpcaFun0Der = x$fpca_fun_0der,
    fpcaFun1Der = x$fpca_fun_1der,
    fpcaFun2Der = x$fpca_fun_2der,
    fpcaFun3Der = x$fpca_fun_3der,
    fpcaFun4Der = x$fpca_fun_4der,
    phenoparams = x$phenoparams,
    mixedmodelStatus = x$mixedmodel_status,
    mixedmodelInverted = x$mixedmodel_inverted,
    optimalNumHarms = x$optimal_num_harms,
    optimalHarmsFPCA = x$optimal_harms_fpca,
    criticalPoints = x$critical_points_fpca
  )
  
  
  # out <- list()
  # out$x <- x$x
  # out$startYear <- startYear
  # out$endYear <- endYear
  # out$freq <- x$freq
  # out$sigma <- x$sigma
  # out$x_smooth <- x$x_smooth
  # out$m_aug_smooth <- x$m_aug_smooth
  # 
  # out$usedTotal <- x$usedTotal
  # out$series <- x$series
  # out$clusterSize <- x$clusterSize
  # out$dominatingClusterSize <- x$dominatingClusterSize
  # out$clustering <- x$clustering
  # 
  # out$fpca <- x$fpca
  # out$fpca_lowerCB <- x$fpca_lowerCB
  # out$fpca_upperCB <- x$fpca_upperCB
  # 
  # out$fpca_harmfit_params <- x$fpca_harmfit_params
  # out$fpca_fun_0der <- x$fpca_fun_0der
  # out$fpca_fun_1der <- x$fpca_fun_1der
  # out$fpca_fun_2der <- x$fpca_fun_2der
  # out$fpca_fun_3der <- x$fpca_fun_3der
  # out$fpca_fun_4der <- x$fpca_fun_4der
  # out$phenoparams <- x$phenoparams
  # # out$status <- x$status
  # 
  # out$mixedmodel_status <- x$mixedmodel_status
  # out$mixedmodel_inverted <- x$mixedmodel_inverted
  # 
  # out$optimal_num_harms <- x$optimal_num_harms
  # out$optimal_harms_fpca <- x$optimal_harms_fpca
  # out$critical_points <- x$critical_points_fpca
  
  out  
}

# ==============================================================================

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# --- FUNCTIONS & OBJECTS used to define sephora-methods
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

# --- Colors used in spiral and phenoParam plots
cgu <- rgb(173/255,221/255,142/255)
csos <- rgb(120/255,198/255,121/255)
cmat <- rgb(49/255, 163/255,84/255)
csen <- rgb(217/255, 95/255, 14/255)
ceos <- rgb(254/255, 153/255, 41/255)
cdor <- rgb(208/255, 209/255, 230/255)

colores <- c(cgu,csos,cmat,csen,ceos,cdor)

# --- to get x-axis for phenoParams plot 

DAYS <- c(31,28,31,30,31,30,31,31,30,31,30,31)

DAYS_AT_YEAR <- c(1,cumsum(DAYS))

middleMonth <- sapply(1:length(DAYS_AT_YEAR), 
                      function(s) median(c(DAYS_AT_YEAR[s],DAYS_AT_YEAR[s+1])) )

middleMonth <- ceiling(middleMonth[!is.na(middleMonth)])

MONTHS <- c("Jan", "Feb", "March", "Abr", "May", "Jun", "Jul",
            "Aug", "Sep", "Oct", "Nov", "Dec")

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# --- AUXILIARY FUNCTIONS 
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

LoadToEnvironment <- function(RData, env = new.env()){
  load(RData, env)
  return(env) 
}

