#' Phenological parameters estimation
#' 
#' Estimation of 6 phenological parameters from a numeric vector or a \code{ts} object. The estimated parameters are: \bold{green up},
#' \bold{start of season}, \bold{maturity}, \bold{senescence}, \bold{end of season} and \bold{dormancy}. These parameters
#' are critical points of some derivatives of an idealized curve which, in turn, is obtained 
#' through a functional principal component analysis (FPCA)-based regression model.
#' 
#' @param              x a \code{ts}-object
#' @param      frequency integer giving number of observations per season. Default is 23.
#' @param         method character. Should \code{OLS} or \code{WLS} be used for smoothing \code{x}
#'                       through a harmonic regression model. See \bold{Details}.
#' @param modelSelection character. Should \code{AIC} or \code{BIC} be employed for selecting the
#'                       the optimal number of frequencies to be used in a harmonic regression model. See \bold{Details}.
#' @param          sigma numeric vector of length equal to \code{frequency}. Each entry gives the 
#'                       standard deviation of observations acquired at same day of the year.
#'                       Pertinent when \code{method=WLS} only. Default, \code{NULL}.
#' @param     var_method character specifying method employed to estimate heterogeneous variance. Methods
#'                       allowed are: \code{standard} (sampled variance), \code{robust-mad} (mad-based variance)
#'                       and \code{robust-Qn} (Qn-based variance). See \bold{Details}.
#' @param      fixedFreq integer specifying number of frequencies/harmonics used in harmonic regression
#'                       model. When specified, \code{modelSelection} is disregarded and same number
#'                       of harmonics is utilized to fit observations from each season. Default, \code{NULL}.
#' @param          delta numeric. Default, \code{0}. When harmonic regression problem is ill-posed, this 
#'                       parameter allows a simple regularization. See \bold{Details}.
#' @param       distance character indicating what distance to use in hierarchical clustering.
#'                       All distances in \code{\link[dtwclust]{tsclust}} are allowed. See 
#'                       \bold{Details}.
#' @param         series numeric vector allowing to specify what time series can be used in fpca estimation.
#'                       Default, \code{NULL}.
#' @param    clusterSize numeric, in the interval \code{(0,1)}, used to specify the size of the dominating cluster.
#'                       Not relevant when \code{series} is provided. Default, \code{0.75}. See \bold{Details}. 
#' @param          basis list giving numeric basis used in FPCA-based regression. See \bold{Details}.                    
#' @param        samples integer with number of samples to draw from smoothed version of \code{x}. Used
#'                       exclusively in Functional Principal Components Analysis (FPCA)-based
#'                       regression. See \bold{Details}.
#' @param           corr Default \code{NULL}. Object defining correlation structure, can be 
#'                       numeric vector, matrix or function.
#' @param              k integer, number of principal components used in the FPCA-based regression.   
#' @param          trace logical. If \code{TRUE}, progress on the hierarchical clustering is printed 
#'                       on console. Default, \code{FALSE}.
#' @param      confiBand Logical, should a confidence band for the FPCA-based regression fit be calculated? 
#'                       Default, \code{FALSE}.
#' @param          alpha numeric, significance level for confidence band. Pertinent when
#'                       \code{confiBand=TRUE} only. Default, \code{0.05}.                   
#' 
#' @export
#' 
#' @importFrom dtwclust tsclust
#' @importFrom geoTS haRmonics
#' @importFrom eBsc drbasis
#' 
#' @note From version 0.1.42 arguments startYear, endYear and numFreq have been discontinued. Instead
#' the value of the former two arguments is inferred from the \code{ts}-object \code{x}. numFreq has been
#' replaced by \code{fixedFreq}.
#' 
#' @details In order to estimate the phenological parameters, first \code{x} is assembled 
#' as a matrix. This matrix has as many rows as years/seasons in the studied period and 
#' as many columns as observations (\code{frequency}) per year. 
#' Then, each vector row of the resulting matrix is smoothed through the harmonic regression model 
#' \code{\link[geoTS]{haRmonics}}. This function allows for homogeneous (\code{OLS}) and 
#' heterogeneous (\code{WLS}) errors in the model; these vectors are stored in \code{x_smooth}. 
#' When \code{method=WLS} and \code{sigma} is not provided, the function \code{\link[geoTS]{hetervar}} 
#' is used to estimate the heterogeneous variance accordingly with the \code{var_method} provided.
#' The engine to fit a harmonic model to \code{x} is the function \code{\link[geoTS]{haRmonics}}.
#' When in need for the optimal number of harmonics in each season, the Akaike Information Criterion 
#' (\code{AIC}) and the Bayesian Information Criterion (\code{BIC}) are allowed through the
#' argument \code{modelSelection}. When in need of using a fixed number of harmonics each season,
#' \code{fixedFreq} must be provided; \code{delta} is an additional parameter for 
#' \code{\link[geoTS]{haRmonics}}.
#' 
#' From the smoothed version of \code{x}, that is, \code{x_smooth}, equally spaced \code{samples} 
#' are drawn from each harmonic regression fit, the resulting observations are stored in the 
#' matrix \code{m_aug_smooth}. 
#' 
#' When in need of using a specific set of time series (years/seasons) as a cluster, 
#' the argument \code{series} must be provided. When the users do not specify these time series, 
#' then hierarchical clustering is used to determine a dominating cluster of time series. 
#' This process is now described.
#' 
#' In order to obtain clusters of years/seasons sharing similar characteristics
#' \code{\link[dtwclust]{tsclust}} is applied to \code{m_aug_smooth}; 2 clusters are 
#' produced which are comprised of some subsets of the vector \code{1:ncol(m_aug_smooth)}. 
#' If the length of the larger subset is greater or equal than the integer part
#' of \code{clusterSize * nrow(x_smooth)}, then this subset of indices is used to 
#' extract (by columns) a submatrix of \code{m_aug_smooth}. 
#' When no dominating cluster can be determined, that is, when the length of neither 
#' of the two clusters is greater than \code{clusterSize * nrow(x_smooth)}, then 
#' the next step is applied to all columns of \code{m_aug_smooth}.
#' 
#' Based on the observations produced in the hierarchical clustering step, a regression 
#' model with the following representation is applied:
#' 
#' \eqn{f_i(t) = \tau(t) + \sum_{j=1}^{k} \varepsilon_j(t) \nu_{ij} + \epsilon_i},
#' 
#' where \eqn{f_i(t)} is substituted by the vector of sample observations of the \eqn{i}-th 
#' year; \eqn{\varepsilon_j(t)} is the \eqn{j}-th functional principal component (FPC); 
#' \eqn{\nu_{ij}} is the score associated with the \eqn{j}-th FPC and the \eqn{i}-th vector
#' of sampled observations; and \eqn{\epsilon_i} is a normally distributed random variable
#' with variance \eqn{\sigma^2}, see \cite{Krivobokova et al. (2022)} for further details. 
#' From this step, an estimate of \eqn{\tau} is produced -\code{fpca}- 
#' this is an idealized version of the original observations contained in \code{x}.
#' 
#' Parameter \code{basis} can be supplied through a call to \code{\link[eBsc]{drbasis}}
#' with parameters \code{nn=samples} and \code{qq=2}. Parameter \code{corr} indicates
#' whether correlation between annual curves must be considered; the current implementation
#' does not incorporate correlation. The number of principal components is controlled
#' by \code{k}. 
#' 
#' Next, a harmonic regression is fitted to \code{fpca} (a numeric vector of length 
#' equal to \code{samples}) with the parameters provided above (\code{method}, \code{sigma}, 
#' \code{modelSelection}, \code{fixedFreq}, \code{delta}, etc.). Based on the estimated 
#' parameters of this fit (\code{fpca_harmfit_params}) an R expression function 
#' is calculated along with its first, second, third and fourth derivatives. These derivatives 
#' are used in establishing the phenological parameters (\code{phenoparams}) utilizing basic calculus
#' criteria similar to what \cite{Baumann et al. (2017)} have proposed.
#' 
#' Finally, when 6 \code{phenoparams} are found \code{status=Success}, otherwise 
#' \code{status=Partial}. 
#' 
#' @return A \code{\link[sephora]{sephora-class}} object containing the following elements
#' \item{x}{ts object}
#' \item{startYear}{numeric, time series initial year}
#' \item{endYear}{numeric, time series final year}
#' \item{freq}{numeric giving number of observations per season. Default is 23.} 
#' \item{sigma}{when \code{method="OLS"}, \code{NULL}; 
#' when \code{method="WLS"}, numeric vector of length equal to \code{freq}}
#' \item{xSmooth}{list of length 4; first 2 entries are vectors giving the optimal 
#' frequency numbers selected for annual smoothing (based on AIC or BIC); last 2 entries are matrices
#' with \code{nrow=length(x)/freq} and \code{ncol=freq} containing
#' smoothed versions of annual time series recorded in \code{x}.}
#' \item{maugSmooth}{matrix with \code{nrow=(length(x)/freq)} and \code{ncol=samples} 
#' containing sampled observations}
#' \item{usedTotal}{logic indicating whether the full amount of time series was used in fpca estimation}
#' \item{series}{numeric vector giving indices of times series used in fpca estimation}
#' \item{clustering}{Formal class \code{HierarchicalTSClusters} with 20 slots. Output from a call 
#' to \code{\link[dtwclust]{tsclust}} with parameters \code{series=maugSmooth},
#' \code{type='h'}, \code{distance=distance}}
#' \item{clusterSize}{numeric, in the interval \code{(0,1)}, used to specify the dominating cluster size}
#' \item{dominatingClusterSize}{integer, number of time series in the dominating cluster}
#' \item{fpca}{numeric vector of length equal to \code{samples}}
#' \item{fpcaLowerCB}{numeric vector of length equal to \code{samples} giving values of 
#' confidence band lower bound}
#' \item{fpcaUpperCB}{numeric vector of length equal to \code{samples} giving values of
#' confidence band upper bound}
#' \item{fpca_harmfit_params}{list of 4: \code{a.coef}, \code{b.coef}, \code{amplitude} 
#' and \code{phase} as in \code{\link[geoTS]{haRmonics}} output.}
#' \item{fpcaFun0Der}{function, harmonic fit for \code{x}}
#' \item{fpcaFun1Der}{function, first derivative of harmonic fit for \code{x}}
#' \item{fpcaFun2Der}{function, second derivative of harmonic fit for \code{x}}
#' \item{fpcaFun3Der}{function, third derivative of harmonic fit for \code{x}}
#' \item{fpcaFun4Der}{function, fourth derivative of harmonic fit for \code{x}}
#' \item{phenoparams}{named numeric vector of length 6}
#' \item{mixedmodelStatus}{character, specifying whether FPCA model was inverted 
#' successfully}
#' \item{mixedmodelInverted}{logic indicating whether FPCA-based regression was
#' successfully fitted}
#' \item{optimalNumHarms}{numeric vector with optimal number of harmonics used to smooth
#' time series forming the dominating cluster}
#' \item{optimalHarmsFPCA}{numeric indicating the optimal harmonic used in final 
#' fit (after FPCA-based regression)}
#' \item{criticalPoints}{character indicating whether a \code{Full} set of phenological 
#' parameters was estimated or only a subset (\code{Partial-i}, with \eqn{i=1,\ldots,5})}
#' @seealso \code{\link[geoTS]{haRmonics}}, \code{\link[geoTS]{hetervar}}, 
#' \code{\link[dtwclust]{tsclust}}, \code{\link[eBsc]{drbasis}}.
#' 
#' @references Krivobokova, T. and Serra, P. and Rosales, F. and Klockmann, K. (2022).
#' \emph{Joint non-parametric estimation of mean and auto-covariances for Gaussian processes}. 
#' Computational Statistics & Data Analysis, \bold{173}, 107519.
#' 
#' @references Baumann, M. and Ozdogan, M. and Richardson, A. and Radeloff, V. (2017).
#' \emph{Phenology from Landsat when data is scarce: Using MODIS and Dynamic Time-Warping to combine 
#' multi-year Landsat imagery to derive annual phenology curves}. International Journal of Applied Earth Observation and Geoinformation,
#' \bold{54}, 72--83 
#' 
phenopar <- function(x, frequency=23, method=c("OLS", "WLS"), 
                         modelSelection=c("AIC", "BIC"), 
                         sigma=NULL, var_method=c("standard", "robust-mad", "robust-Qn"),
                         # numFreq, 
                         fixedFreq=NULL,delta=0, 
                         distance, series=NULL, clusterSize=0.75,
                         # clusterSize = ceiling(0.75*length(startYear:endYear)), 
                         basis, samples, corr=NULL, k, 
                         trace=FALSE, confiBand=FALSE, alpha=0.05){
  
  if( !inherits(x, "ts") ){
    stop("x must be a ts object")
  } else {
    startYear <- stats::start(x)[1]
    endYear <- stats::end(x)[1]
  }
  
  method <- match.arg(method)
  
  modelSelection <- match.arg(modelSelection)
  
  var_method <- match.arg(var_method)
  
  # if(method=="WLS"){
  #   if(is.null(sigma)){
  #     stop("sigma must be provided when WLS method is used")
  #   }
  # }
  
  if(missing(distance)){
    stop("'distance' must be provided")
  }
  
  if( clusterSize <= 0 | clusterSize > 1 ){
    stop("'clusterSize' must be in interval (0,1)")
  }
  
  if(missing(basis)){
    stop("'basis' must be provided")
  }
  
  if(missing(samples)){
    if(missing(basis)){
      stop("'samples' must be provided")
    } else {
      samples <- length(basis[["x"]])
    }
  } else {
    if(samples != length(basis[["x"]])){
      stop("Dimensions of 'samples' and 'basis' must be in correspondance")
    }
  }
  
  if(missing(k)){
    stop("'k' must be provided")
  }
  
  # if( confiBand ){
  #   if( missing(alpha) ){
  #     stop("When confiBand=TRUE, alpha must be provided")
  #   }
  # } else {
  #   alpha <- NULL
  # }
  
  output <- phenopar_tryCatch(x=x, frequency=frequency, method=method,
                              modelSelection=modelSelection, sigma=sigma, 
                              var_method=var_method,
                              fixedFreq=fixedFreq,
                              # numFreq=numFreq, 
                              delta=delta, distance=distance, series=series,
                              clusterSize=clusterSize, samples=samples, basis=basis, 
                              corr=corr, k=k, trace=trace, confiBand=confiBand, 
                              alpha=alpha)
  
  out_sephora <- toSephoraClass(x=output, startYear=startYear, endYear=endYear)
  
  sephora.out <- structure(out_sephora, class="sephora")
  
  sephora.out
}

