#' Visualization of data as a ggplot profile curve
#' 
#' Building block of \code{sephora} plot method. Here the focus is on displaying data as a profile curve 
#' using the ggplot grammar. Here profile curve means that at each time-point there will be more than one observation. 
#' 
#' @param               x a \code{\link[sephora]{sephora-class}} object or a \code{ts}-object are allowed.
#' @param        sizeLine a numeric indicating \code{linewidth} aesthetic in \code{geom_line} as defined in \code{\link[ggplot2]{geom_path}}.
#' @param       sizePoint a numeric indicating \code{size} aesthetic as in \code{\link[ggplot2]{geom_point}}.
#' @param position_legend character, where legend should be displayed. See \code{legend.position} in 
#'                        \code{\link[ggplot2]{theme}}.
#' @param    title_legend character, legend title. See \code{color} in \code{\link[ggplot2]{labs}}.
#' @param            xLab character, x-axis label. See \code{x} in \code{\link[ggplot2]{labs}}.
#' @param            yLab character, y-axis label. See \code{y} in \code{\link[ggplot2]{labs}}.
#' @param            xLim a vector of length 2 whose entries define beginning and ending dates of period
#'                        to show.
#' @param           xAxis character vector with length equal to number of time-points to display.
#' @param             ... Other graphical arguments passed on to \code{\link[ggplot2]{theme}}.
#' 
#' @export
#' 
#' @importFrom ggplot2 ggplot
#' @importFrom ggplot2 ggplot_build
#' @importFrom ggplot2 aes
#' 
#' @return A \code{\link[ggplot2]{ggplot}} object.
#' 
#' @seealso \code{\link[sephora]{get_metadata_years}}.
#' 
rmPlot <- function(x, 
                   # startYear, endYear, frequency,
                   sizeLine=1, sizePoint=2, position_legend="none",
                   xLab="Time", yLab="Index", title_legend=NULL,
                   xLim, xAxis = NULL, ...){
  

  if( inherits(x, "ts") ){
    startYear <- stats::start(x=x)[1]
    endYear <- stats::end(x=x)[1]
    freq <- stats::frequency(x=x)
    y <- x
    X <- as.numeric(y)
  }
  
  if( inherits(x, "sephora") ){
    startYear <- x$startYear
    endYear <- x$endYear
    freq <- x$freq
    X <- as.numeric(c(x$x))
  }
  
  if( is.null(xAxis) ){
    DdA <- seq(1, 365, by=ceiling(365/freq))
  } else {
    DdA <- xAxis
  }
  
  frequency <- freq
  
  out_aux <- tsPlot(x=x, xLab=xLab, yLab=xLab)
  
  # out_aux <- tsPlot(x=x, startYear = startYear, endYear = endYear,
  #                    frequency = frequency, xLab=xLab, yLab=xLab)
  # title_legend = NULL)
  COLORS <- unique( ggplot_build(out_aux)$data[1][[1]]$colour )
  
  # DdA <- seq(1, 365, by=ceiling(365/frequency))
  
  x_axis <- get_metadata_years(x=X, startYear=startYear, endYear=endYear,
                               frequency=frequency)
  
  if( missing(xLim) ){
    df <- data.frame(DoY=factor(DdA, levels=DdA),
                     years=as.factor(rep(x_axis$xLabels, each=frequency)),
                     values=as.numeric(X))
    
    # Abril 14, 2026: Removed "..." from ggplot, kept only "..." in theme
    out <- ggplot(data=df, aes(x=DoY, y=values, group=years, colour=years)) +
      ggplot2::geom_line(linewidth = sizeLine) + ggplot2::geom_point(size = sizePoint) +
      ggplot2::labs(y=yLab, x=xLab, color=title_legend) +
      ggplot2::theme(legend.position = position_legend, ...)#,
    # legend.title = element_text(title_legend))
  } else {
    ind_begin <- (1:length(x_axis$xDates))[x_axis$xDates == xLim[1]]
    
    ind_end <- which.min( (as.numeric(x_axis$xDates)-as.numeric(xLim[2]))^2 )
    
    A <- strsplit(as.character(xLim[1]),"-")
    B <- strsplit(as.character(xLim[2]),"-")
    
    LABELS <- (as.numeric(A[[1]][1]) %% 100):(as.numeric(B[[1]][1]) %% 100)
    
    positions_labels_in_xAxis <- match(LABELS, x_axis$xLabels)
    
    remainder <- length(ind_begin:ind_end) %% frequency
    
    x <- as.numeric(X)
    x <- x[ind_begin:(ind_end-remainder)]
    
    df <- data.frame(DoY=factor(DdA, levels=DdA),
                     # years=as.factor(rep(x_axis$xLabels[LABELS+1],
                     #                     each=frequency)),
                     years=as.factor(rep(LABELS, each=frequency)),
                     values=x)
    
    out <- ggplot(data=df, aes(x=DoY, y=values,
                               group=years,
                               colour=years ), ...) +
      ggplot2::geom_line(linewidth = sizeLine) + ggplot2::geom_point(size = sizePoint) +
      ggplot2::labs(y=yLab, x=xLab, color=title_legend) +
      ggplot2::theme(legend.position = position_legend, ...) +
      # legend.title = element_text(title_legend)) +
      ggplot2::scale_color_manual(values = COLORS[positions_labels_in_xAxis])
  }
  
  out
}
