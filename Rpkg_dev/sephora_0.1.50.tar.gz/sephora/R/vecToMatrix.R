#' Mapping numeric vector to a matrix
#' 
#' Maps a vector (observations of a -pixel- satellite time series) to a matrix.
#' 
#' @param         x a numeric vector whose length must be a multiple of \code{lenPeriod}.
#' @param lenPeriod a numeric, number of observations per period
#' @param rowName character, output matrix's column names. Default, \code{year}.
#' @param colName chracter, output matrix's row names. Default, \code{DoA}.
#' 
#' @export
#' 
#' @return A named-matrix with \code{nrow} equal to \code{length(x)/lenPeriod} and
#' \code{ncol} equal to \code{lenPeriod}.
#' 
#' @seealso \code{\link[sephora]{fill_initialgap_MOD13Q1}}, \code{\link[sephora]{phenopar}}, 
#' \code{\link[sephora]{vecFromData}}.
#' 
vecToMatrix <- function(x, lenPeriod = NULL, 
                           rowName = "year", colName = "DoA") {
  
  # x=PIXEL_ts
  
  # Validate input class
  if (!inherits(x, c("numeric", "ts"))) {
    stop("'x' must be either a numeric vector or a 'ts' object")
  }
  
  # Handle ts input
  if (inherits(x, "ts")) {
    lenPeriod <- stats::frequency(x)
    years <- seq(from = stats::start(x)[1], to = stats::end(x)[1])
    rowPrefix <- years
  } else {
    # Handle numeric input
    if (is.null(lenPeriod)) {
      stop("When 'x' is numeric, 'lenPeriod' must be provided")
    }
  }
  
  # Validate length
  if (length(x) %% lenPeriod != 0) {
    stop("Length of 'x' must be a multiple of 'lenPeriod'")
  }
  
  # Reshape
  output <- matrix(x, ncol = lenPeriod, byrow = TRUE)
  
  # Row names
  # rownames(output) <- paste0(rowName, 
  #                            if (inherits(x, "ts")) "" else seq_len(nrow(output)))
  rownames(output) <- paste0(rowName, seq_len(nrow(output)))
  
  # Column names
  colnames(output) <- paste0(colName, seq_len(ncol(output)))
  
  return(output)
}
