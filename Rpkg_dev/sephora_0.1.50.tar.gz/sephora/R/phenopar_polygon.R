#' Phenological parameter estimation in mass
#' 
#' Estimation of phenological parameters on a set of numeric vectors via parallel computing. 
#'
#' @param               path character with full path of RData file containing numeric vectors to analyze.
#' @param            product character specifying whether dataset is the \code{MOD13Q1} product (default) or 
#'                           a different one (\code{independent}).
#' @param               data matrix with dataset to analyze. Pertinent when \code{product="independent"} only.                           
#' @param          frequency integer giving number of observations per season. Default, 23.
#' @param             method character. Should \code{OLS} or \code{WLS} be used for smoothing each
#'                           numeric vector in analyzed dataset?
#' @param     modelSelection character. Should \code{AIC} or \code{BIC} be employed for selecting the
#'                           the optimal number of frequencies to be used in a harmonic regression model. 
#' @param           save_all logic. Should all output objects be saved? Default is \code{FALSE}. 
#' @param          save_some character vector giving the names of the output objects that should be
#'                           saved. See \bold{Details}.                            
#' @param              sigma numeric vector of length equal to \code{frequency}. Each entry gives the 
#'                           standard deviation of observations acquired at same day of the year. 
#'                           Pertinent when \code{method=WLS} only. Default, \code{NULL}.
#' @param         var_method character specifying method employed to estimate heterogeneous variance. 
#'                           Methods allowed are: \code{standard} (sampled variance), \code{robust-mad} 
#'                           (mad-based variance) and \code{robust-Qn} (Qn-based variance).
#' @param          fixedFreq integer specifying number of frequencies/harmonics are used in harmonic regression 
#'                           model. When specified, \code{modelSelection} is disregarded and same number 
#'                           of harmonics is utilized to fit observations from each season. Default, \code{NULL}.
#' @param              delta numeric. Default, 0. When regression problem is ill-posed, this
#'                           parameter allows a simple regularization.
#' @param           distance character indicating what distance to use in hierarchical clustering.
#'                           All distances in \code{\link[dtwclust]{tsclust}} are allowed.
#' @param             series numeric vector allowing to specify what time series can be used in fpca estimation.
#' @param        clusterSize numeric, in the interval \code{(0,1)}, used to specify the size of the dominating cluster.
#'                           Not relevant when \code{series} is provided. Default, \code{0.75}. 
#' @param              basis list giving numeric basis used in FPCA-based regression. See \bold{Details}.                           
#' @param            samples integer with number of samples to draw from smoothed version of numeric
#'                           vector to analyze. Used exclusively in Functional Principal Components Analysis (FPCA)-based
#'                           regression.
#' @param               corr Default \code{NULL}. Object defining correlation structure, can be
#'                           numeric vector, matrix or function.
#' @param                  k integer, number of principal components used in FPCA-based regression.
#' @param              trace logical. If \code{TRUE}, progress on the hierarchical clustering
#'                           is printed on console. Default, \code{FALSE}.
#' @param          confiBand Logical, should a confidence band for the FPCA-based regression fit be calculated? 
#'                           Default, \code{FALSE}.
#' @param              alpha numeric, significance level for confidence band. Pertinent when
#'                           \code{confiBand=TRUE} only. Default, \code{0.05}.                   
#' @param           numCores integer. How many processing cores can be used?
#' @param          dirToSave character. In which directory analysis results should be saved?
#' @param reportFileBaseName character. What base name should be given to a progress report file? 
#'                           Default, \code{phenopar_progress}.
#' @param outputFileBaseName character. What base name should be given to the output file? 
#'                           Default, \code{polygon}.                            
#'
#' @export
#' 
#' @details \code{save_some} must be a subset of the valid output objects: \code{c("x", "freq", "sigma",
#' "x_smooth", "m_aug_smooth", "usedTotal", "series", "clustering", "clusterSize", "fpca", "fpca_lowerCB", 
#' "fpca_upperCB", "fpca_harmfit_params","fpca_fun_0der", "fpca_fun_1der", "fpca_fun_2der", "fpca_fun_3der", 
#' "fpca_fun_4der", "phenoparams","status")}.
#' 
#' Parameter \code{basis} can be supplied by a call to \code{\link[eBsc]{drbasis}}
#' with parameters \code{nn=samples} and \code{qq=2}. 
#'
#' @importFrom doParallel registerDoParallel
#' @importFrom foreach foreach
#' @importFrom foreach %dopar%
#' @importFrom parallel stopCluster
#' @importFrom utils globalVariables
#' @importFrom dtwclust tsclust
#' @importFrom geoTS haRmonics
#' @importFrom geoTS hetervar
#' @importFrom eBsc drbasis
#' @importFrom rootSolve uniroot.all
#'
#' @return At the location specified by \code{dirToSave}, a file containing a matrix
#' with \code{nrow} equal to the number of numeric vectors analyzed and 6 columns, is saved. 
#' When \code{path} is provided, the name of this file is:
#' 
#' \code{paste0(tools::file_path_sans_ext(basename(path)), "_phenoparams.RData")}.
#'
#' When \code{data} is provided, the name of the output file is:
#' 
#' \code{paste0(outputFileBaseName, "_phenoParams.RData"))}.
#'
#' @seealso \code{\link[sephora]{phenopar}}, \code{\link[dtwclust]{tsclust}}.
#'
phenopar_polygon <- function(path=NULL, product=c("MOD13Q1", "independent"), data,
                             frequency=23, method=c("OLS", "WLS"), modelSelection=c("AIC", "BIC"),
                             save_all=FALSE, save_some, 
                             sigma=NULL, var_method = c("standard", "robust-mad", "robust-mad"),
                             fixedFreq=NULL, delta=0, distance, 
                             series=NULL,
                             clusterSize=0.75, 
                             basis, samples, corr=NULL,
                             k, trace=FALSE, confiBand=FALSE, alpha=0.05, 
                             numCores=20, dirToSave,
                             reportFileBaseName="phenopar_progress",
                             outputFileBaseName="polygon"){
  
  product <- match.arg(product)
  if(product == "MOD13Q1"){
    if(is.null(path)){
      stop('path must be provided')
    }
    
    dataEnv <- LoadToEnvironment(RData=path)
    data <- get(x="poly", envir=dataEnv)[[1]]
    
  } else {
    if(missing(data)){
      stop('data must be provided')
    }
  }
  
  method <- match.arg(method)
  
  modelSelection <- match.arg(modelSelection)
  
  var_method <- match.arg(var_method)
  
  if(save_all){
    objectsToSave <- validObjects
  } else {
    if(missing(save_some)){
      stop("save_some must provided")
    } else {
      toExtract <- intersect(x=validObjects, y=save_some)
      objectsToSave <- toExtract
    }
  }
  
  # if(missing(numFreq)){
  #   stop("numFreq must provided")
  # }
  
  if(missing(distance)){
    stop("distance must provided")
  }
  
  if( clusterSize <= 0 | clusterSize > 1 ){
    stop("'clusterSize' must be in interval (0,1)")
  }
  
  if(missing(basis)){
    stop("basis must provided")
  }
  
  if(missing(samples)){
    if(missing(basis)){
      stop("samples must provided")
    } else {
      samples <- length(basis[["x"]])
    }
  } else {
    if(samples != length(basis[["x"]])){
      stop("Dimensions of 'samples' and 'basis' must be in correspondance")
    }
  }
  
  if(missing(k)){
    stop("k must be provided")
  }
  
  if(missing(dirToSave)){
    stop('dirToSave must be provided')
  }
  
  # check later cos maybe product is not needed here when data="MOD13Q1"
  output <- phenopar_polygon_tryCatch(data=data, product=product, frequency=frequency, method=method,
                                      var_method=var_method,
                                      sigma=sigma, fixedFreq=fixedFreq, delta=delta, distance=distance,
                                      series=series,modelSelection=modelSelection,
                                      clusterSize=clusterSize,
                                      samples=samples, basis=basis, corr=corr, k=k, trace=trace,
                                      confiBand=confiBand, alpha=alpha,
                                      numCores=numCores,
                                      objectsToSave=objectsToSave,
                                      dirToSave=dirToSave,
                                      reportFileBaseName=reportFileBaseName)
  
    
  save(output, file = paste0(dirToSave, "/",
                             ifelse( !is.null(path), 
                                     tools::file_path_sans_ext(basename(path)), 
                                     outputFileBaseName ),
                             "_phenoParams.RData"))
  
}
