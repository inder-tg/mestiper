#' Visualization of data as a ggplot time series
#' 
#' Building block of \code{sephora} plot method. Here the focus is on displaying data as a time series using the ggplot grammar.
#' 
#' @param               x a \code{\link[sephora]{sephora-class}} object and a \code{ts}-object are allowed.
#' @param        sizeLine a numeric, setting \code{linewidth} aesthetic in \code{geom_line} as defined in \code{\link[ggplot2]{geom_path}}.
#' @param       sizePoint a numeric, setting \code{size} aesthetic as in \code{\link[ggplot2]{geom_point}}.
#' @param position_legend character, where legend should be displayed. See \code{legend.position} in 
#'                        \code{\link[ggplot2]{theme}}.
#' @param    title_legend character, plot title. See \code{color} in \code{\link[ggplot2]{labs}}.
#' @param            xLab character, x-axis label. See \code{x} in \code{\link[ggplot2]{labs}}.
#' @param            yLab character, y-axis label. See \code{y} in \code{\link[ggplot2]{labs}}.
#' @param            xLim a vector of length 2 whose entries define beginning and ending dates of period
#'                        to show.
#' @param             ... Other graphical arguments passed on to \code{\link[ggplot2]{theme}} system.
#' 
#' @export
#' 
#' @importFrom ggplot2 ggplot
#' @importFrom ggplot2 ggplot_build
#' @importFrom ggplot2 aes
#' 
#' @return A \code{\link[ggplot2]{ggplot}} object.
#' 
#' @seealso \code{\link[sephora]{get_metadata_years}}.
#' 
tsPlot <- function(x, sizeLine=1, sizePoint=2, position_legend="none",
                   title_legend=NULL, xLab="Time", yLab="Index", xLim, ...){
  
  
  # x=sephora_pixel
  
  if( inherits(x, "ts") ){
    startYear <- stats::start(x=x)[1]
    endYear <- stats::end(x=x)[1]
    freq <- stats::frequency(x=x)
    y <- x
    X <- as.numeric(y)
  }
  
  if( inherits(x, "sephora") ){
    startYear <- x$startYear
    endYear <- x$endYear
    freq <- x$freq
    X <- as.numeric(c(x$x))
  }
  
  # xInput <- x
  
  frequency <- freq
  
  x_axis <- get_metadata_years(x=X, startYear=startYear,
                               endYear=endYear,
                               frequency=frequency)
  
  df <- data.frame(values=X,
                   years=as.factor(rep(x_axis$xLabels, each=frequency)),
                   x=x_axis$xDates)
  
  if( missing(xLim) ){
    # Dec 10, 2023: Added "..." below
    # March 24, 2026: Removed "..." from ggplot, kept only "..." in theme
    out <- ggplot(df, aes(x=x, y=values, color=years)) +
      ggplot2::geom_line(linewidth=sizeLine) + ggplot2::geom_point(size=sizePoint) +
      ggplot2::labs(x=xLab, y=yLab, color=title_legend) +
      ggplot2::theme(legend.position = position_legend, ...)
    
  } else {
    out_aux <- ggplot(data = df, aes(x=x, y=values, color=years)) +
      ggplot2::geom_line(linewidth=sizeLine) + ggplot2::geom_point(size=sizePoint) +
      ggplot2::theme(legend.position = position_legend) +
      ggplot2::labs(x=xLab, y=yLab)
    
    COLORS <- unique( ggplot_build(out_aux)$data[1][[1]]$colour )
    
    ind_begin <- (1:length(x_axis$xDates))[x_axis$xDates == xLim[1]]
    
    ind_end <- which.min( (as.numeric(x_axis$xDates)-as.numeric(xLim[2]))^2 )
    
    A <- strsplit(as.character(xLim[1]),"-")
    B <- strsplit(as.character(xLim[2]),"-")
    
    LABELS <- (as.numeric(A[[1]][1]) %% 100):(as.numeric(B[[1]][1]) %% 100)
    
    positions_labels_in_xAxis <- base::match(LABELS, x_axis$xLabels)
    
    remainder <- length(ind_begin:ind_end) %% frequency
    
    xInput <- X[ind_begin:(ind_end-remainder)]
    # x <- xCopy[ind_begin:(ind_end-remainder)]
    
    df <- data.frame(x=x_axis$xDates[ind_begin:(ind_end-remainder)],
                     # years=as.factor(rep(x_axis$xLabels[LABELS],
                     #                     each=frequency)),
                     years=as.factor(rep(LABELS, each=frequency)),
                     values=xInput)
    
    # Dec 10, 2023: Added "..." below
    # March 24, 2026: Removed "..." from ggplot, kept only "..." in theme
    out <- ggplot(data=df, aes(x=x, y=values, colour=years)) +
      ggplot2::geom_line(linewidth = sizeLine) + ggplot2::geom_point(size = sizePoint) +
      ggplot2::labs(y=yLab, x=xLab, color=title_legend) +
      ggplot2::theme(legend.position = position_legend, ...) +
      # legend.title = ggplot2::element_text(title_legend) ) +
      ggplot2::scale_color_manual(values = COLORS[positions_labels_in_xAxis])
  }
  
  out
}
